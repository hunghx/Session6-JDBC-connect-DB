create
    definer = root@localhost procedure transaction_demo()
begin
  start transaction ;
  set autocommit = ON; # tắt tính tính năng tự động commit
#    các câu lệnh , ccs giao dịch được thực hiến
      update product set price = price + 50 where id=1; # 150
      update product set price = price - 75 where id=4;
      update product set price = price - 100 where id=5;
      update product set price = price + 50 where id=6;
  commit ;

end;

