create
    definer = root@localhost procedure findByID(IN idPro int)
begin
    select * from product where id =idPro;
end;

